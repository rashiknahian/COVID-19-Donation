# COVID-19-Donation


## This repo contains a MVP which will help to give and receive donation in this crisis situation of Bangladesh due to COVID-19


## Technology Used :

* HTML5
* CSS
* Bootstrap v4.3.1 
* PHP
* MySQL